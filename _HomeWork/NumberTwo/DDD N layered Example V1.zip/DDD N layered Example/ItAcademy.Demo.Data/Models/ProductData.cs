﻿namespace ItAcademy.Demo.Data.Models
{
    public class ProductData
    {
        public string Name { get; set; }
    }
}
