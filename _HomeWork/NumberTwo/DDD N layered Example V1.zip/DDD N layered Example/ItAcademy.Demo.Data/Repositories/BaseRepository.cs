﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItAcademy.Demo.Data.Repositories
{
    public class BaseRepository : IBaseRepository
    {
        public int Get()
        {
            throw new NotImplementedException();
        }
    }
}
