﻿using ItAcademy.Demo.Data.Models;

namespace ItAcademy.Demo.Data.Repositories
{
    public interface IProductRepository : IBaseRepository
    {
        ProductData GetMostPopular();
    }
}