﻿namespace ItAcademy.Demo.Data.Repositories
{
    public interface IBaseRepository
    {
        int Get();
    }
}