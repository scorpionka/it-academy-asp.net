﻿using System;
using ItAcademy.Demo.Data.Models;

namespace ItAcademy.Demo.Data.Repositories
{
    public class ProductRepository : BaseRepository, IProductRepository
    {
        public ProductData GetMostPopular()
        {
            throw new NotImplementedException();
        }
    }
}
