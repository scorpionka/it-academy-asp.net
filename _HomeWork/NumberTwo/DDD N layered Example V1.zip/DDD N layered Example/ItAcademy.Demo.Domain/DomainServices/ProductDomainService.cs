﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItAcademy.Demo.Data.Models;
using ItAcademy.Demo.Data.Repositories;
using ItAcademy.Demo.Domain.Models;

namespace ItAcademy.Demo.Domain.DomainServices
{
    public class ProductDomainService : IProductDomainService
    {
        private readonly IProductRepository productRepository;

        public ProductDomainService(IProductRepository productRepository)
        {
            this.productRepository = productRepository;
        }

        public Product GetMostPopular()
        {
            ProductData productData = productRepository.GetMostPopular();

            //Product product = Mapper.Map<ProductData, Product>(productData);

            throw new NotImplementedException();
        }
    }
}
