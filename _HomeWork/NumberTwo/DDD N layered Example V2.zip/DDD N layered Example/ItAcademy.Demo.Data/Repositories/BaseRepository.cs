﻿using System;
using ItAcademy.Demo.Domain.Repositories;

namespace ItAcademy.Demo.Data.Repositories
{
    public class BaseRepository : IBaseRepository
    {
        public int Get()
        {
            throw new NotImplementedException();
        }
    }
}
