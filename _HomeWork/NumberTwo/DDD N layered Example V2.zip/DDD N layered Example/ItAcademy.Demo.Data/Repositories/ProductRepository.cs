﻿using System;
using ItAcademy.Demo.Domain.Models;
using ItAcademy.Demo.Domain.Repositories;

namespace ItAcademy.Demo.Data.Repositories
{
    public class ProductRepository : BaseRepository, IProductRepository
    {
        public Product GetMostPopular()
        {
            throw new NotImplementedException();
        }
    }
}
