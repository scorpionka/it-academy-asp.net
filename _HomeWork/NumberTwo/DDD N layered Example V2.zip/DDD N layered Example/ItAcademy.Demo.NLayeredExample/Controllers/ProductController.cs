﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ItAcademy.Demo.Domain.DomainServices;
using ItAcademy.Demo.Domain.Models;
using ItAcademy.Demo.NLayeredExample.Models;

namespace ItAcademy.Demo.NLayeredExample.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductDomainService productDomainService;

        public ProductController(IProductDomainService productDomainService)
        {
            this.productDomainService = productDomainService;
        }


        // GET: Product
        public ActionResult GetMostPopular()
        {
            Product product = productDomainService.GetMostPopular();

            //ProductView productView = Mapper.Map<Product, ProductView>(product);

            throw new NotImplementedException();

            //return View(productView);
        }
    }
}