﻿using ItAcademy.Demo.Domain.Models;
using ItAcademy.Demo.Domain.Repositories;

namespace ItAcademy.Demo.Domain.DomainServices
{
    public class ProductDomainService : IProductDomainService
    {
        private readonly IProductRepository productRepository;

        public ProductDomainService(IProductRepository productRepository)
        {
            this.productRepository = productRepository;
        }

        public Product GetMostPopular()
        {
            Product productData = productRepository.GetMostPopular();


            return productData;
        }
    }
}
