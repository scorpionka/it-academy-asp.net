﻿using ItAcademy.Demo.Domain.Models;

namespace ItAcademy.Demo.Domain.DomainServices
{
    public interface IProductDomainService
    {
        Product GetMostPopular();
    }
}