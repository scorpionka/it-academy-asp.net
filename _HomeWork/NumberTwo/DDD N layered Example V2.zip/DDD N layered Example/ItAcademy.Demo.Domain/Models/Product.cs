﻿namespace ItAcademy.Demo.Domain.Models
{
    public class Product
    {
        public string Name { get; set; }
    }
}
