﻿using ItAcademy.Demo.Domain.Models;

namespace ItAcademy.Demo.Domain.Repositories
{
    public interface IProductRepository : IBaseRepository
    {
        Product GetMostPopular();
    }
}