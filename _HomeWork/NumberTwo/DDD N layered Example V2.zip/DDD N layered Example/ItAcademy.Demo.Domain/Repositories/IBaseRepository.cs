﻿namespace ItAcademy.Demo.Domain.Repositories
{
    public interface IBaseRepository
    {
        int Get();
    }
}